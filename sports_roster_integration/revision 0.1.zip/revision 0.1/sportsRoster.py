import sys
from mlb_dedup import mlbThali
from nba_thali import nbaThali
from nfl_thali import nflThali
from nhl_thali import nhlThali
from soccer_thali import soccerThali,soccerDedup


class sport(object):
	infile = sys.argv[1]
	outfile = sys.argv[2]
	third = 'soccer_final.tsv'
	
	def main(self):
		if self.infile == "mlb_raw.tsv":
			mlbThali(self.infile,self.outfile)
		elif self.infile == "nba_raw.tsv":
			nbaThali(self.infile,self.outfile)
		elif self.infile == 'nfl_raw.tsv':
			nflThali(self.infile,self.outfile)
		elif self.infile == 'nhl_raw.tsv':
			nhlThali(self.infile,self.outfile)
		elif self.infile == 'soccer_raw.tsv':
			soccerThali(self.infile,self.outfile)
			soccerDedup(self.outfile,self.third)
		else:
			print 'failed!'


if __name__=="__main__":
	sport().main()