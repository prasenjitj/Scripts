import re
from collections import defaultdict
from collections import OrderedDict

#thali conversion
def soccerThali(str1,str2):
	print 'soccer thali script invoked'

	f=open(str1,'r')

	data=f.read().strip()
	data=data.split('\n')
	header=data[0]
	d={}
	d1={}
	dd=defaultdict(list)
	#print data
	list1=[]
	list2=[]
	values=[]

	code_mapper = {
					'A1': 'SPLGROSTAusFeb011',
					 'AR1N': 'SPLGROSTArg',
					 'AUS1': 'SPLGROSTAusFeb01',
					 'BE1': 'SPLGROSTBel',
					 'BRA1': 'SPLGROSTCam',
					 'CAN': 'SPLGROSTCanFeb01',
					 'DK1': 'SPLGROSTDan',
					 'ES1': 'SPLGROSTLalFeb01',
					 'FI1': 'SPLGROSTFin',
					 'FR1': 'SPLGROSTLig',
					 'GB1': 'SPLGROSTEngFeb012',
					 'GB2': 'SPLGROSTEngFeb013',
					 'GB3': 'SPLGROSTEngFeb011',
					 'GB4': 'SPLGROSTEngFeb01',
					 'GR1': 'SPLGROSTSupFeb011',
					 'IR1': 'SPLGROSTRep',
					 'IT1': 'SPLGROSTSerFeb012',
					 'IT2': 'SPLGROSTIta',
					 'KR1': 'SPLGROSTCro',
					 'L1': 'SPLGROSTGerFeb01',
					 'MEXA': 'SPLGROSTMex',
					 'MLS1': 'SPLGROSTMls',
					 'NL1': 'SPLGROSTDut',
					 'PL1': 'SPLGROSTPol',
					 'PO1': 'SPLGROSTPor',
					 'RO1': 'SPLGROSTRom',
					 'RSK1': 'SPLGROSTKor',
					 'RU1': 'SPLGROSTRusFeb01',
					 'SC1': 'SPLGROSTScoFeb01',
					 'SER1': 'SPLGROSTSerFeb01',
					 'SL1': 'SPLGROSTSloFeb01',
					 'SLO1': 'SPLGROSTSlo',
					 'TR1': 'SPLGROSTTur',
					 'TS1': 'SPLGROSTCze',
					 'UKR1': 'SPLGROSTUkr',
					 'UNG1': 'SPLGROSTHun'
					 }


	key=header.split('\t')
	#print key
	#
	for i in range(1,len(data)):
	    value=data[i]
	    value=value.split('\t')
	    #print value
	    if value[9] != '2016':
	    	value = ''	
	    new=OrderedDict(zip(key,value))
	    #print new
	    if new:

	        list1.append(new)
	    else:
	        pass
	        #print 'dictionary is empty'
	record= list1
	#print record
	for j in record:
		url = j['url']
		
		url = re.sub(r'\s*REC#\s*',"/",url)
		url = re.sub(r'\\','/',url)
		url = re.sub(r'\d{4}-\d{2}-\d{2}','',url)

		
		#print type(url)
		#j['URL'] = url
		j['url'] = url
		#print j['url']
		#print j['URL']
		for k, v in code_mapper.items():
			if j['code'] == k:
				tag=v
				j['tag'] = tag
		#print j['tag1']
		#print type(j['tag']), j['tag']
		#task_name = j['Player_name']
		#j['task_name'] = task_name 
		#ex_id = j['transaction_id']+'#'+j['player']+'#'+j['team']+'#'+j['type']
		#print  ex_id
		description = '*Find or create each transaction and curate as per guidelines* Player Name: '+j['Player_name']+' # From Team: '+j['From_Team']+' # To Team: '+j['To_Team']+' # Transaction Date: '+j['Date']+' # URL: '+j['url']
		task_type = '/soccer/football_player'
		j['description']=description
		#j['external_id']=ex_id
		j['Task_Type'] = task_type
		list2.append(j)
	#print list2


	for x in list2:
		tag=x.keys()
		tag=tuple(tag)
	#print tag

	dd2=defaultdict(list)

	with open (str2,'w') as f1:
		#f1.write('\t'.join(tag)+'\n')
		for row in list2:
			for k in tag:
				
				if k not in row.keys():
					dd[k]=''
					#print 'false'
				else:
					dd[k]=row[k]
					#print 'true', row[k]
				dd2[k].append(dd[k])

		'''		
		#print dd2
		f1.write('\t'.join(dd2.keys())+'\n')
		for v in zip(*dd2.values()):	
			#print '\t'.join(v),'\n'		
			f1.write('\t'.join(v)+'\n')	
		'''	

		wanted_keys = ['task_type','task_name','url','description','tag','external_id']
		final_dict=OrderedDict([(a,dd2[a]) for a in wanted_keys if a in dd2])
		#print final_dict

		f1.write('\t'.join(final_dict.keys())+'\n')
		for b in zip(*final_dict.values()):
			f1.write('\t'.join(b)+'\n')

#dedup function
def soccerDedup(str1,str2):
	print 'soccer dedup script invoked'
	f=open(str1,'r')
	data=f.read().strip()
	data=data.split('\n')
	header=data[0]
	header=header.split('\t')
	#print header[-1]
	d={}
	d1={}
	dd=defaultdict(list)
	#print data
	list1=[]
	list2=[]
	values=[]

	for i in data:
		key=re.findall(r'\d{8}.*',i)
		key=tuple(key)
		#print 'key :: ',key
		value=re.findall(r'^(.*?)\t\d{8}#',i)
		#value=''.join(value)
		#value=re.sub(r'\s*REC#.*','',value).split()
		#print type(value)
		#print 'value :: ',value
		new=OrderedDict(zip(key,value))
		#print new
		list1.append(new)
		#print list1
	
		for x in range(0,len(key)):
			dd[key[x]]=[]
			dd=OrderedDict(dd)
		#print dd
	tag=tuple(dd.keys())
	#print tag

	dd2=defaultdict(list)

	with open (str2,'w') as f1:
		f1.write(header[0]+'\t'+header[1]+'\t'+header[2]+'\t'+header[3]+'\t'+header[4]+'\t'+header[-1]+'\n')
		for row in list1:
			#print row
			for k in tag:
				if k not in row.keys():
					#dd[k] = ''
					#print 'false'
					continue
				else:
					#print k
					dd[k] = row[k]
					#print 'true'
				dd2[k].append(dd[k])
		#print dd2
		
		for v1, v2 in dd2.items():
			#print '-----------'
			#print v1,'#######',v2[0]

			f1.write(v2[0]+'\t'+v1+'\n')		